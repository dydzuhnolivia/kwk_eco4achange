
// when you click button see all articles it takes you to featured articles page
var seeAllArticlesBtn =$("button"); 

seeAllArticlesBtn.on ("click", sendUserToFeatArticles);

function sendUserToFeatArticles (){
location.replace ("./featuredArticles.html");
} 






var imgOne =$("containerOne");

imgOne.on("click",sendUserToOutsideArtices);

function sendUserToOutsideArtices () {
  location.replace ("https://www.nytimes.com/2019/09/03/books/review/how-fast-fashion-is-destroying-the-planet.html");
}